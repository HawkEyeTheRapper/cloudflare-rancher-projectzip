# Design Guidelines: Chat Log Parser & Memory Bank

## Design Approach

**System-Based with Custom Identity**: Using **Material Design** principles for information-dense layouts with custom enhancements reflecting the technical/mythological "EverLight" brand identity. Focus on data clarity, processing visualization, and dual-output presentation.

## Typography Hierarchy

**Font Families**:
- Primary: Inter (via Google Fonts) - clean, technical readability
- Monospace: JetBrains Mono - for code blocks, log displays, file paths

**Hierarchy**:
- H1 (Page titles): text-3xl, font-semibold
- H2 (Section headers): text-2xl, font-semibold  
- H3 (Subsections): text-xl, font-medium
- Body: text-base, font-normal
- Code/Logs: text-sm, font-mono
- Captions/Meta: text-xs, font-medium

## Layout System

**Spacing Units**: Tailwind units of **2, 4, 6, 8, 12, 16** for consistent rhythm
- Component padding: p-6 or p-8
- Section spacing: space-y-6 or space-y-8
- Grid gaps: gap-4 or gap-6
- Container max-width: max-w-7xl

**Grid Structure**:
- Main upload area: Single column, centered
- Processing view: 2-column split (50/50) - left: markdown preview, right: MCP structure
- File list: Single column with expandable cards

## Core Components

**Upload Zone**:
- Large dropzone area (min-h-96)
- Dashed border treatment indicating drag-drop capability
- Icon + primary text + supporting text stacked vertically
- Centered alignment with generous padding (p-12)

**File Processing Cards**:
- Elevated card design with subtle borders
- Header: filename + timestamp + badge (status indicator)
- Body: Progress indicator or completion summary
- Expandable sections for parsed data preview
- Padding: p-6, spacing: space-y-4

**Dual Output Display**:
- Split-pane layout (grid-cols-2)
- Left pane: Markdown preview with formatted rendering
- Right pane: Structured JSON/MCP tree view
- Synchronized scrolling between panes
- Headers for each pane with export buttons
- Monospace font for technical displays

**Navigation**:
- Top horizontal nav bar (h-16)
- Logo/title left-aligned
- Action buttons right-aligned (Upload New, Settings)
- Sticky positioning during scroll

**Data Tables** (for log history):
- Striped rows for readability
- Sortable column headers
- Compact row height (h-12)
- Actions column (View, Export, Delete)

**Forms & Inputs**:
- File input styled as primary button
- Settings toggles for parsing options
- Text inputs for custom metadata fields
- Labels positioned above inputs
- Focus states with outline treatment

## Interaction Patterns

**File Upload Flow**:
1. Dropzone with hover state transition
2. File validation feedback (instant)
3. Processing progress bar (indeterminate → determinate)
4. Success state with preview generation

**Data Exploration**:
- Expandable/collapsible sections for parsed conversations
- Click to expand message threads
- Highlight search/filter results
- Copy-to-clipboard buttons for code blocks

**Export Actions**:
- Download buttons for markdown files
- "Import to MCP" action button
- Batch operations for multiple files
- Clear success/error notifications

## Page Structure

**Main Dashboard**:
- Hero upload zone (takes 60% viewport initially)
- Recent uploads grid below (3-column on desktop, responsive)
- Quick stats bar (total logs processed, storage used)

**Processing View** (post-upload):
- Breadcrumb navigation
- File info header
- Dual-pane content area
- Bottom action bar (sticky) with export options

**Settings Page**:
- Single column form layout
- Grouped sections (Parsing Options, Export Preferences, MCP Configuration)
- Save changes button bottom-right

## Images

**Icon System**: Material Icons via CDN for:
- Upload cloud icon in dropzone
- File type indicators (chat, document icons)
- Status badges (checkmark, loading spinner, error)
- Action icons (download, copy, trash, settings)

**No Hero Image**: This is a utility application - focus remains on functional interface rather than marketing visuals.

**Avatar Placeholders**: Small circular avatars in message previews (w-8 h-8) using initials on solid backgrounds.

## Responsive Behavior

- Desktop (lg): Full dual-pane layouts, 3-column grids
- Tablet (md): 2-column grids, stacked processing views with tab switching
- Mobile (base): Single column throughout, vertical stack for all content, full-width components

**Touch Optimization**:
- Larger tap targets (min h-12) for mobile
- Swipe actions for file list items
- Bottom sheet modals for mobile forms