# 🌟 EverLight Re-Ignite — Campaign Notebook

This JupyterLab folder maintains memory-safe context for Ethan Womack (Hawk Eye).

## Structure:
- `/notebooks/`: Primary notebooks.
- `/user_updates/`: Drop markdown or text to update memory.
- `/config/`: Config snapshots.
- `/logs/`: Sync logs and history.
