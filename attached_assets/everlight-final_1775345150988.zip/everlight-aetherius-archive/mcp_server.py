import uvicorn
import logging
import os

from everlight_context.config import Config
from everlight_context.mcp.server import MCPServer

# Configure logging
logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO").upper(),
                    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

if __name__ == "__main__":
    # Load configuration
    config_path = os.getenv("CONFIG_PATH", "config.yaml")
    config = Config(config_path=config_path)

    # Initialize MCP Server
    mcp_server = MCPServer(config=config)
    app = mcp_server.get_app()

    # Run FastAPI app with Uvicorn
    logger.info(f"Starting MCP server on {config.mcp_server.host}:{config.mcp_server.port}")
    uvicorn.run(app, host=config.mcp_server.host, port=config.mcp_server.port)
