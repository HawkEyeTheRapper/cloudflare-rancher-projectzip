import logging
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from typing import Dict, Any, List

from everlight_context.config import Config
from everlight_context.models.ollama_client import OllamaClient
from everlight_context.models.embedding_model import EmbeddingModel
from everlight_context.models.document_processor import DocumentProcessor, Document
from everlight_context.storage.document_store import DocumentStore
from everlight_context.api.nextcloud_client import NextcloudClient

logger = logging.getLogger(__name__)

class MCPServer:
    """FastAPI-based HTTP server implementing the MCP protocol."""

    def __init__(self, config: Config):
        self.app = FastAPI(
            title="EverLight Aetherius Archive MCP Server",
            description="Model Context Protocol server for Nextcloud Assistant integration.",
            version="0.1.0",
        )
        self.config = config

        # Initialize core components
        self.ollama_client = OllamaClient(base_url=self.config.ollama.url)
        self.embedding_model = EmbeddingModel(
            ollama_client=self.ollama_client, model_name=self.config.ollama.model
        )
        self.document_processor = DocumentProcessor(
            ollama_client=self.ollama_client,
            embedding_model=self.embedding_model,
            llm_model_name=self.config.ollama.model,
        )
        self.document_store = DocumentStore(db_path=self.config.storage.database_path)
        self.nextcloud_client = NextcloudClient(api_config=self.config.api)

        self._setup_routes()

    def _setup_routes(self):
        @self.app.get("/health")
        async def health_check() -> Dict[str, str]:
            """Health check endpoint."""
            ollama_ok = await self.ollama_client.health_check()
            if ollama_ok:
                return {"status": "ok", "ollama": "connected"}
            raise HTTPException(status_code=503, detail="Ollama service unavailable")

        @self.app.get("/mcp/v1/tools")
        async def get_tools() -> List[Dict[str, Any]]:
            """Returns the list of available MCP tools."""
            # This will be populated by tool_handler.py
            return [
                {
                    "name": "list_documents",
                    "description": "List all documents in the archive.",
                    "input_schema": {"type": "object", "properties": {}},
                    "output_schema": {"type": "array", "items": {"type": "object"}},
                },
                {
                    "name": "get_document",
                    "description": "Retrieve a document by its ID.",
                    "input_schema": {"type": "object", "properties": {"document_id": {"type": "string"}}},
                    "output_schema": {"type": "object"},
                },
                {
                    "name": "search_documents",
                    "description": "Search for documents using a semantic query.",
                    "input_schema": {"type": "object", "properties": {"query": {"type": "string"}, "top_k": {"type": "integer", "default": 5}}},
                    "output_schema": {"type": "array", "items": {"type": "object"}},
                },
                {
                    "name": "summarize_document",
                    "description": "Generate a summary for a document by its ID.",
                    "input_schema": {"type": "object", "properties": {"document_id": {"type": "string"}}},
                    "output_schema": {"type": "object", "properties": {"summary": {"type": "string"}}},
                },
                {
                    "name": "analyze_document",
                    "description": "Perform a detailed analysis for a document by its ID.",
                    "input_schema": {"type": "object", "properties": {"document_id": {"type": "string"}}},
                    "output_schema": {"type": "object", "properties": {"analysis": {"type": "string"}}},
                },
            ]

        @self.app.post("/mcp/v1/tools/{tool_name}/invoke")
        async def invoke_tool(tool_name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
            """Invokes a specific MCP tool."""
            if tool_name == "list_documents":
                docs = self.document_store.list_documents()
                return {"documents": [d.to_dict() for d in docs]}
            elif tool_name == "get_document":
                document_id = payload.get("document_id")
                if not document_id: raise HTTPException(status_code=400, detail="document_id is required")
                doc = self.document_store.get_document(document_id)
                if not doc: raise HTTPException(status_code=404, detail="Document not found")
                return {"document": doc.to_dict()}
            elif tool_name == "search_documents":
                query = payload.get("query")
                top_k = payload.get("top_k", 5)
                if not query: raise HTTPException(status_code=400, detail="query is required")

                all_docs_with_embeddings = [
                    Document.from_dict({"id": d["id"], "filename": d["filename"], "embedding": d["embedding"]})
                    for d in self.document_store.get_all_embeddings()
                ]
                search_results = await self.embedding_model.search_similar(query, [d.to_dict() for d in all_docs_with_embeddings], top_k)
                return {"results": search_results}
            elif tool_name == "summarize_document":
                document_id = payload.get("document_id")
                if not document_id: raise HTTPException(status_code=400, detail="document_id is required")
                doc = self.document_store.get_document(document_id)
                if not doc: raise HTTPException(status_code=404, detail="Document not found")
                if not doc.summary:
                    doc.summary = await self.document_processor.summarize(doc.content)
                    self.document_store.add_document(doc) # Update document with summary
                return {"summary": doc.summary}
            elif tool_name == "analyze_document":
                document_id = payload.get("document_id")
                if not document_id: raise HTTPException(status_code=400, detail="document_id is required")
                doc = self.document_store.get_document(document_id)
                if not doc: raise HTTPException(status_code=404, detail="Document not found")
                if not doc.analysis:
                    doc.analysis = await self.document_processor.analyze(doc.content)
                    self.document_store.add_document(doc) # Update document with analysis
                return {"analysis": doc.analysis}
            else:
                raise HTTPException(status_code=404, detail="Tool not found")

        @self.app.get("/mcp/v1/resources")
        async def get_resources() -> List[Dict[str, Any]]:
            """Returns the list of available MCP resources."""
            # This will be populated by resource_handler.py
            return [
                {
                    "uri": "archive://index",
                    "description": "An index of all documents in the EverLight Aetherius Archive.",
                    "content_type": "application/json",
                },
                {
                    "uri": "archive://documents/{document_id}",
                    "description": "A specific document from the EverLight Aetherius Archive.",
                    "content_type": "text/plain",
                },
            ]

        @self.app.get("/mcp/v1/resources/{resource_uri:path}")
        async def get_resource_content(resource_uri: str) -> Any:
            """Retrieves the content of a specific MCP resource."""
            if resource_uri == "archive://index":
                docs = self.document_store.list_documents()
                return JSONResponse(content=[{"id": d.id, "filename": d.filename, "summary": d.summary} for d in docs])
            elif resource_uri.startswith("archive://documents/"):
                document_id = resource_uri.split("archive://documents/")[1]
                doc = self.document_store.get_document(document_id)
                if not doc: raise HTTPException(status_code=404, detail="Document not found")
                return doc.content
            else:
                raise HTTPException(status_code=404, detail="Resource not found")


    def get_app(self) -> FastAPI:
        return self.app
