import os
import yaml
from dotenv import load_dotenv
from typing import Any, Dict

class Config:
    """Manages configuration loading from YAML and environment variables."""

    def __init__(self, config_path: str = "config.yaml"):
        load_dotenv()  # Load environment variables from .env file
        self.config = self._load_config(config_path)

    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Loads configuration from a YAML file and overrides with environment variables."""
        with open(config_path, "r") as f:
            config_data = yaml.safe_load(f)

        # Override with environment variables
        for key, value in config_data.items():
            if isinstance(value, dict):
                for sub_key, sub_value in value.items():
                    env_var_name = f"{key.upper()}_{sub_key.upper()}"
                    if isinstance(sub_value, str) and sub_value.startswith("${") and sub_value.endswith("}"):
                        # Handle ${VAR_NAME} syntax
                        var_name = sub_value[2:-1]
                        config_data[key][sub_key] = os.getenv(var_name, config_data[key][sub_key])
                    else:
                        config_data[key][sub_key] = os.getenv(env_var_name, config_data[key][sub_key])
            else:
                env_var_name = key.upper()
                config_data[key] = os.getenv(env_var_name, config_data[key])
        return config_data

    def get(self, key: str, default: Any = None) -> Any:
        """Retrieves a configuration value by key."""
        parts = key.split(".")
        current_config = self.config
        for part in parts:
            if isinstance(current_config, dict) and part in current_config:
                current_config = current_config[part]
            else:
                return default
        return current_config

    def __getitem__(self, key: str) -> Any:
        return self.get(key)

    def __getattr__(self, key: str) -> Any:
        return self.get(key)
