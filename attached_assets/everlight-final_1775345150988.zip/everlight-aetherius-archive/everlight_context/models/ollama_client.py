import httpx
import asyncio
import logging
from typing import Any, Dict, List
from everlight_context.models.base_model import BaseModel

logger = logging.getLogger(__name__)

class OllamaClient(BaseModel):
    """Client for interacting with the local Ollama API."""

    def __init__(self, base_url: str = "http://ollama:11434", timeout: int = 60):
        self.base_url = base_url
        self.timeout = timeout
        self.client = httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout)

    async def _request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Helper for making HTTP requests to the Ollama API."""
        try:
            response = await self.client.request(method, endpoint, **kwargs)
            response.raise_for_status()
            return response.json()
        except httpx.RequestError as e:
            logger.error(f"Ollama request error for {endpoint}: {e}")
            raise ConnectionError(f"Could not connect to Ollama at {self.base_url}: {e}")
        except httpx.HTTPStatusError as e:
            logger.error(f"Ollama API error for {endpoint}: {e.response.status_code} - {e.response.text}")
            raise ValueError(f"Ollama API returned an error: {e.response.status_code} - {e.response.text}")

    async def generate(self, prompt: str, model: str, **kwargs) -> str:
        """Generates text based on a prompt using Ollama."""
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            **kwargs
        }
        response = await self._request("POST", "/api/generate", json=payload)
        return response.get("response", "")

    async def embed(self, text: str, model: str, **kwargs) -> List[float]:
        """Generates embeddings for a given text using Ollama."""
        payload = {
            "model": model,
            "prompt": text,
            **kwargs
        }
        response = await self._request("POST", "/api/embeddings", json=payload)
        return response.get("embedding", [])

    async def list_models(self) -> List[Dict[str, Any]]:
        """Lists available models from Ollama."""
        response = await self._request("GET", "/api/tags")
        return response.get("models", [])

    async def health_check(self) -> bool:
        """Checks the health of the Ollama service."""
        try:
            # A simple request that doesn't require a model, like listing models, can serve as a health check.
            await self.list_models()
            return True
        except (httpx.RequestError, ValueError):
            return False

    async def close(self):
        """Closes the HTTP client session."""
        await self.client.aclose()
