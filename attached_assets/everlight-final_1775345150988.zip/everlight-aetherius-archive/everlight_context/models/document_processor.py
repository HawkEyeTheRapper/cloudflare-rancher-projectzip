import asyncio
import logging
from typing import Any, Dict, List, Optional
from everlight_context.models.ollama_client import OllamaClient
from everlight_context.models.embedding_model import EmbeddingModel

logger = logging.getLogger(__name__)

class Document:
    """Represents a document in the archive."""
    def __init__(
        self,
        id: Optional[str] = None,
        filename: str = "",
        content: str = "",
        summary: Optional[str] = None,
        analysis: Optional[str] = None,
        embedding: Optional[List[float]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        self.id = id
        self.filename = filename
        self.content = content
        self.summary = summary
        self.analysis = analysis
        self.embedding = embedding
        self.metadata = metadata if metadata is not None else {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "filename": self.filename,
            "content": self.content,
            "summary": self.summary,
            "analysis": self.analysis,
            "embedding": self.embedding,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        return cls(
            id=data.get("id"),
            filename=data.get("filename", ""),
            content=data.get("content", ""),
            summary=data.get("summary"),
            analysis=data.get("analysis"),
            embedding=data.get("embedding"),
            metadata=data.get("metadata"),
        )


class DocumentProcessor:
    """Processes documents using Ollama for summarization, analysis, and embeddings."""

    def __init__(
        self, ollama_client: OllamaClient, embedding_model: EmbeddingModel, llm_model_name: str
    ):
        self.ollama_client = ollama_client
        self.embedding_model = embedding_model
        self.llm_model_name = llm_model_name

    async def summarize(self, text: str) -> str:
        """Generates a summary of the given text using Ollama."""
        prompt = f"Summarize the following document concisely:\n\n{text}"
        try:
            summary = await self.ollama_client.generate(prompt, self.llm_model_name)
            return summary.strip()
        except Exception as e:
            logger.error(f"Error summarizing document: {e}")
            return f"Error summarizing document: {e}"

    async def analyze(self, text: str) -> str:
        """Performs a deeper analysis of the given text using Ollama."""
        prompt = f"Provide a detailed analysis of the following document, highlighting key themes, arguments, and potential implications:\n\n{text}"
        try:
            analysis = await self.ollama_client.generate(prompt, self.llm_model_name)
            return analysis.strip()
        except Exception as e:
            logger.error(f"Error analyzing document: {e}")
            return f"Error analyzing document: {e}"

    async def process(self, document: Document) -> Document:
        """Processes a single document: generates summary, analysis, and embeddings."""
        logger.info(f"Processing document: {document.filename}")
        if not document.content:
            logger.warning(f"Document {document.filename} has no content to process.")
            return document

        # Generate summary and analysis concurrently
        summary_task = self.summarize(document.content)
        analysis_task = self.analyze(document.content)
        embedding_task = self.embedding_model.embed(document.content)

        summary, analysis, embedding = await asyncio.gather(
            summary_task, analysis_task, embedding_task
        )

        document.summary = summary
        document.analysis = analysis
        document.embedding = embedding
        logger.info(f"Finished processing document: {document.filename}")
        return document

    async def process_batch(self, documents: List[Document]) -> List[Document]:
        """Processes a batch of documents concurrently."""
        logger.info(f"Processing batch of {len(documents)} documents.")
        processed_documents = await asyncio.gather(
            *[self.process(doc) for doc in documents]
        )
        logger.info(f"Finished processing batch of {len(documents)} documents.")
        return processed_documents
