from abc import ABC, abstractmethod
from typing import Any, Dict, List

class BaseModel(ABC):
    """Abstract base class for all models."""

    @abstractmethod
    async def generate(self, prompt: str, model: str, **kwargs) -> str:
        """Generates text based on a prompt."""
        pass

    @abstractmethod
    async def embed(self, text: str, model: str, **kwargs) -> List[float]:
        """Generates embeddings for a given text."""
        pass

    @abstractmethod
    async def list_models(self) -> List[Dict[str, Any]]:
        """Lists available models."""
        pass

    @abstractmethod
    async def health_check(self) -> bool:
        """Checks the health of the model service."""
        pass
