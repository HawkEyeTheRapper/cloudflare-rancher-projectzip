import numpy as np
from typing import List, Dict, Any
from everlight_context.models.ollama_client import OllamaClient

class EmbeddingModel:
    """Handles embedding generation and similarity search using Ollama."""

    def __init__(self, ollama_client: OllamaClient, model_name: str):
        self.ollama_client = ollama_client
        self.model_name = model_name

    async def embed(self, text: str) -> List[float]:
        """Generates an embedding vector for a given text."""
        return await self.ollama_client.embed(text, self.model_name)

    async def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Generates embedding vectors for a batch of texts."""
        # Ollama's /api/embeddings endpoint doesn't directly support batching in a single request.
        # We'll simulate it by making individual requests concurrently.
        embeddings = await asyncio.gather(*[self.ollama_client.embed(text, self.model_name) for text in texts])
        return embeddings

    def _cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """Calculates the cosine similarity between two vectors."""
        vec1_np = np.array(vec1)
        vec2_np = np.array(vec2)
        dot_product = np.dot(vec1_np, vec2_np)
        norm_a = np.linalg.norm(vec1_np)
        norm_b = np.linalg.norm(vec2_np)
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot_product / (norm_a * norm_b)

    async def search_similar(self, query: str, documents: List[Dict[str, Any]], top_k: int = 5) -> List[Dict[str, Any]]:
        """Performs a cosine similarity search for a query against a list of documents.

        Args:
            query: The search query string.
            documents: A list of dictionaries, where each dictionary must contain 'text' and 'embedding' keys.
            top_k: The number of top similar documents to return.

        Returns:
            A list of dictionaries, each containing the original document and its similarity score,
            sorted by similarity in descending order.
        """
        query_embedding = await self.embed(query)
        if not query_embedding:
            return []

        results = []
        for doc in documents:
            if 'embedding' in doc and doc['embedding']:
                similarity = self._cosine_similarity(query_embedding, doc['embedding'])
                results.append({"document": doc, "similarity": similarity})

        results.sort(key=lambda x: x["similarity"], reverse=True)
        return results[:top_k]
