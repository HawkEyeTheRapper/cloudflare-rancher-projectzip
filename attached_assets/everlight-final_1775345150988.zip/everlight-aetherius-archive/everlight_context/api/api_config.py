from typing import Dict, Any

class APIConfig:
    """Configuration for external APIs."""
    def __init__(self, config: Dict[str, Any]):
        self._config = config

    @property
    def nextcloud_url(self) -> str:
        return self._config.get("nextcloud", {}).get("url", "")

    @property
    def nextcloud_username(self) -> str:
        return self._config.get("nextcloud", {}).get("username", "")

    @property
    def nextcloud_app_password(self) -> str:
        return self._config.get("nextcloud", {}).get("app_password", "")
