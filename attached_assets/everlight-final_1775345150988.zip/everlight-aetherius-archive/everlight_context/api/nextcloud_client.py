import logging
from typing import List, Dict, Any, Optional
from nextcloud import NextCloud
from everlight_context.api.api_config import APIConfig

logger = logging.getLogger(__name__)

class NextcloudClient:
    """Client for interacting with Nextcloud for file access and Assistant API integration."""

    def __init__(self, api_config: APIConfig):
        self.api_config = api_config
        self.nc = NextCloud(
            self.api_config.nextcloud_url,
            user=self.api_config.nextcloud_username,
            password=self.api_config.nextcloud_app_password
        )

    async def _connect(self):
        """Establishes connection to Nextcloud. Nextcloud.login() is synchronous."""
        try:
            self.nc.login()
            logger.info("Successfully connected to Nextcloud.")
        except Exception as e:
            logger.error(f"Failed to connect to Nextcloud: {e}")
            raise ConnectionError(f"Could not connect to Nextcloud: {e}")

    async def list_files(self, path: str = '/') -> List[Dict[str, Any]]:
        """Lists files and folders in a given Nextcloud path."""
        await self._connect()
        try:
            files = self.nc.list(path)
            return [{
                "name": f.name,
                "path": f.path,
                "is_dir": f.is_dir(),
                "size": f.size,
                "last_modified": f.last_modified
            } for f in files]
        except Exception as e:
            logger.error(f"Error listing files from Nextcloud path {path}: {e}")
            return []

    async def download_file(self, remote_path: str, local_path: str) -> bool:
        """Downloads a file from Nextcloud to a local path."""
        await self._connect()
        try:
            self.nc.download_file(remote_path, local_path)
            logger.info(f"Downloaded {remote_path} to {local_path}")
            return True
        except Exception as e:
            logger.error(f"Error downloading file {remote_path} from Nextcloud: {e}")
            return False

    async def upload_file(self, local_path: str, remote_path: str) -> bool:
        """Uploads a file from a local path to Nextcloud."""
        await self._connect()
        try:
            self.nc.put_file(remote_path, local_path)
            logger.info(f"Uploaded {local_path} to {remote_path}")
            return True
        except Exception as e:
            logger.error(f"Error uploading file {local_path} to Nextcloud: {e}")
            return False

    async def get_file_content(self, remote_path: str) -> Optional[str]:
        """Gets the content of a file from Nextcloud as a string."""
        await self._connect()
        try:
            content = self.nc.get_file_contents(remote_path)
            return content.decode("utf-8") # Assuming text files
        except Exception as e:
            logger.error(f"Error getting content for {remote_path} from Nextcloud: {e}")
            return None

    # Placeholder for Nextcloud Assistant API integration
    async def send_to_assistant(self, message: str, file_id: Optional[str] = None) -> Dict[str, Any]:
        """Sends a message to the Nextcloud Assistant API. (Conceptual)"""
        logger.warning("Nextcloud Assistant API integration is conceptual and not fully implemented here.")
        # In a real scenario, this would involve making an HTTP request to the Nextcloud Assistant API endpoint.
        # The exact endpoint and payload would depend on the Nextcloud Assistant API specification.
        return {"status": "success", "response": f"Received message for assistant: {message}"}
