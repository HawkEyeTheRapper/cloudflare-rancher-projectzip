import sqlite3
import json
import logging
from typing import List, Dict, Any, Optional
from everlight_context.models.document_processor import Document

logger = logging.getLogger(__name__)

class DocumentStore:
    """Manages local document storage and indexing using SQLite."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._initialize_db()

    def _initialize_db(self):
        """Initializes the SQLite database and creates the documents table if it doesn't exist."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS documents (
                    id TEXT PRIMARY KEY,
                    filename TEXT NOT NULL,
                    content TEXT,
                    summary TEXT,
                    analysis TEXT,
                    embedding BLOB,
                    metadata TEXT
                )
            """)
            conn.commit()
        logger.info(f"Initialized document store at {self.db_path}")

    def _serialize_embedding(self, embedding: List[float]) -> bytes:
        """Serializes a list of floats (embedding) to bytes."""
        return json.dumps(embedding).encode('utf-8')

    def _deserialize_embedding(self, embedding_blob: bytes) -> List[float]:
        """Deserializes bytes to a list of floats (embedding)."""
        if embedding_blob is None:
            return []
        return json.loads(embedding_blob.decode('utf-8'))

    def add_document(self, document: Document):
        """Adds a single document to the store."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            embedding_blob = self._serialize_embedding(document.embedding) if document.embedding else None
            metadata_json = json.dumps(document.metadata) if document.metadata else None
            cursor.execute("""
                INSERT OR REPLACE INTO documents (id, filename, content, summary, analysis, embedding, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                document.id,
                document.filename,
                document.content,
                document.summary,
                document.analysis,
                embedding_blob,
                metadata_json,
            ))
            conn.commit()
        logger.info(f"Added/Updated document: {document.filename} (ID: {document.id})")

    def get_document(self, document_id: str) -> Optional[Document]:
        """Retrieves a document by its ID."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM documents WHERE id = ?", (document_id,))
            row = cursor.fetchone()
            if row:
                doc_data = {
                    "id": row[0],
                    "filename": row[1],
                    "content": row[2],
                    "summary": row[3],
                    "analysis": row[4],
                    "embedding": self._deserialize_embedding(row[5]) if row[5] else None,
                    "metadata": json.loads(row[6]) if row[6] else {},
                }
                return Document.from_dict(doc_data)
        return None

    def list_documents(self) -> List[Document]:
        """Lists all documents in the store."""
        documents = []
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM documents")
            for row in cursor.fetchall():
                doc_data = {
                    "id": row[0],
                    "filename": row[1],
                    "content": row[2],
                    "summary": row[3],
                    "analysis": row[4],
                    "embedding": self._deserialize_embedding(row[5]) if row[5] else None,
                    "metadata": json.loads(row[6]) if row[6] else {},
                }
                documents.append(Document.from_dict(doc_data))
        return documents

    def delete_document(self, document_id: str):
        """Deletes a document by its ID."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM documents WHERE id = ?", (document_id,))
            conn.commit()
        logger.info(f"Deleted document with ID: {document_id}")

    def search_documents_by_text(self, query: str) -> List[Document]:
        """Searches documents by matching query in content, summary, or analysis."""
        documents = []
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            search_query = f"%{query}%"
            cursor.execute("""
                SELECT * FROM documents
                WHERE content LIKE ? OR summary LIKE ? OR analysis LIKE ? OR filename LIKE ?
            """, (search_query, search_query, search_query, search_query))
            for row in cursor.fetchall():
                doc_data = {
                    "id": row[0],
                    "filename": row[1],
                    "content": row[2],
                    "summary": row[3],
                    "analysis": row[4],
                    "embedding": self._deserialize_embedding(row[5]) if row[5] else None,
                    "metadata": json.loads(row[6]) if row[6] else {},
                }
                documents.append(Document.from_dict(doc_data))
        return documents

    def get_all_embeddings(self) -> List[Dict[str, Any]]:
        """Retrieves all document IDs, filenames, and their embeddings."""
        embeddings_data = []
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, filename, embedding FROM documents WHERE embedding IS NOT NULL")
            for row in cursor.fetchall():
                embeddings_data.append({
                    "id": row[0],
                    "filename": row[1],
                    "embedding": self._deserialize_embedding(row[2])
                })
        return embeddings_data

    def count_documents(self) -> int:
        """Returns the total number of documents in the store."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM documents")
            return cursor.fetchone()[0]
