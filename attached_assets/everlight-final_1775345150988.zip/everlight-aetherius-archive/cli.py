import click
import asyncio
import logging
import os
from typing import Optional

from everlight_context.config import Config
from everlight_context.models.ollama_client import OllamaClient
from everlight_context.models.embedding_model import EmbeddingModel
from everlight_context.models.document_processor import DocumentProcessor, Document
from everlight_context.storage.document_store import DocumentStore
from everlight_context.api.nextcloud_client import NextcloudClient

# Configure logging
logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO").upper(),
                    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Global instances (initialized once)
config: Optional[Config] = None
ollama_client: Optional[OllamaClient] = None
embedding_model: Optional[EmbeddingModel] = None
document_processor: Optional[DocumentProcessor] = None
document_store: Optional[DocumentStore] = None
nextcloud_client: Optional[NextcloudClient] = None

def _init_components():
    global config, ollama_client, embedding_model, document_processor, document_store, nextcloud_client
    if config is None:
        config_path = os.getenv("CONFIG_PATH", "config.yaml")
        config = Config(config_path=config_path)

        ollama_client = OllamaClient(base_url=config.ollama.url)
        embedding_model = EmbeddingModel(
            ollama_client=ollama_client, model_name=config.ollama.model
        )
        document_processor = DocumentProcessor(
            ollama_client=ollama_client,
            embedding_model=embedding_model,
            llm_model_name=config.ollama.model,
        )
        document_store = DocumentStore(db_path=config.storage.database_path)
        nextcloud_client = NextcloudClient(api_config=config.api)

@click.group()
def cli():
    """EverLight Aetherius Archive CLI Tool."""
    _init_components()

@cli.command()
@click.argument("file_path", type=click.Path(exists=True))
async def process(file_path: str):
    """Processes a document, generating summary, analysis, and embeddings."""
    click.echo(f"Processing document: {file_path}")
    with open(file_path, "r") as f:
        content = f.read()
    filename = os.path.basename(file_path)
    doc_id = os.path.splitext(filename)[0] # Simple ID for now

    doc = Document(id=doc_id, filename=filename, content=content)
    processed_doc = await document_processor.process(doc)
    document_store.add_document(processed_doc)
    click.echo(f"Document {filename} processed and stored with ID: {processed_doc.id}")
    click.echo(f"Summary: {processed_doc.summary[:200]}...")

@cli.command()
@click.argument("query")
@click.option("--top-k", default=5, type=int, help="Number of top results to return.")
async def search(query: str, top_k: int):
    """Performs a semantic search across archived documents."""
    click.echo(f"Searching for: '{query}' (top {top_k} results)")
    all_docs_with_embeddings = [
        Document.from_dict({"id": d["id"], "filename": d["filename"], "embedding": d["embedding"]})
        for d in document_store.get_all_embeddings()
    ]
    results = await embedding_model.search_similar(query, [d.to_dict() for d in all_docs_with_embeddings], top_k)

    if results:
        click.echo("\nSearch Results:")
        for res in results:
            doc = res["document"]
            click.echo(f"  - Document ID: {doc["id"]}")
            click.echo(f"    Filename: {doc["filename"]}")
            click.echo(f"    Similarity: {res["similarity"]:.4f}")
            click.echo("    --------------------")
    else:
        click.echo("No similar documents found.")

@cli.command(name="list")
async def list_docs():
    """Lists all documents in the archive."""
    click.echo("Listing all documents:")
    docs = document_store.list_documents()
    if docs:
        for doc in docs:
            click.echo(f"  - ID: {doc.id}, Filename: {doc.filename}, Summary: {doc.summary[:100]}...")
    else:
        click.echo("No documents in the archive.")

@cli.command()
@click.argument("document_id")
async def summarize(document_id: str):
    """Summarizes a document by its ID."""
    doc = document_store.get_document(document_id)
    if not doc:
        click.echo(f"Document with ID {document_id} not found.")
        return
    if not doc.summary:
        click.echo(f"Generating summary for document ID: {document_id}...")
        doc.summary = await document_processor.summarize(doc.content)
        document_store.add_document(doc) # Update document with summary
    click.echo(f"Summary for {doc.filename}:\n{doc.summary}")

@cli.command()
@click.argument("document_id")
async def analyze(document_id: str):
    """Analyzes a document by its ID."""
    doc = document_store.get_document(document_id)
    if not doc:
        click.echo(f"Document with ID {document_id} not found.")
        return
    if not doc.analysis:
        click.echo(f"Generating analysis for document ID: {document_id}...")
        doc.analysis = await document_processor.analyze(doc.content)
        document_store.add_document(doc) # Update document with analysis
    click.echo(f"Analysis for {doc.filename}:\n{doc.analysis}")

@cli.command()
async def status():
    """Checks the status of Ollama connection and document count."""
    click.echo("Checking system status...")
    ollama_status = await ollama_client.health_check()
    click.echo(f"Ollama Connection: {'OK' if ollama_status else 'FAILED'}")
    doc_count = document_store.count_documents()
    click.echo(f"Documents in Archive: {doc_count}")

@cli.command()
@click.argument("directory", type=click.Path(exists=True, file_okay=False, dir_okay=True))
async def ingest(directory: str):
    """Bulk ingests documents from a directory."""
    click.echo(f"Ingesting documents from directory: {directory}")
    documents_to_process = []
    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read()
                filename = os.path.basename(file_path)
                doc_id = os.path.splitext(filename)[0] # Simple ID for now
                documents_to_process.append(Document(id=doc_id, filename=filename, content=content))
            except Exception as e:
                logger.error(f"Could not read file {file_path}: {e}")

    if documents_to_process:
        click.echo(f"Found {len(documents_to_process)} documents to ingest. Processing in batch...")
        processed_docs = await document_processor.process_batch(documents_to_process)
        for doc in processed_docs:
            document_store.add_document(doc)
        click.echo(f"Successfully ingested and processed {len(processed_docs)} documents.")
    else:
        click.echo("No documents found or readable in the specified directory.")


if __name__ == "__main__":
    asyncio.run(cli())
