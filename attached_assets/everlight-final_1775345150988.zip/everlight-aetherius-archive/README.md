# EverLight Aetherius Archive

The EverLight Aetherius Archive is a robust document management and analysis system designed for seamless integration with Nextcloud and local Ollama models. It provides two primary interfaces: a Model Context Protocol (MCP) server for Nextcloud Assistant integration and a command-line interface (CLI) for direct operator interaction.

## Key Features

- **Dockerized Deployment**: Runs as a Docker container, easily integrated into a Docker Compose stack alongside Nextcloud and Ollama.
- **Ollama Integration**: Leverages a local Ollama instance for all LLM tasks, including document summarization, analysis, and embeddings.
- **Model Context Protocol (MCP) Server**: Exposes a FastAPI-based server compatible with Nextcloud Assistant, enabling AI-powered document interactions within Nextcloud.
- **CLI Tool**: A comprehensive command-line interface for managing the archive, processing documents, running semantic searches, and monitoring system status.
- **Nextcloud Integration**: Connects to Nextcloud for file access and potential future assistant API integrations.
- **SQLite Document Store**: Efficiently stores documents, their metadata, summaries, analyses, and embeddings in a local SQLite database.
- **Configurable**: Utilizes a `config.yaml` file and environment variables for flexible configuration.

## Architecture Overview

```mermaid
graph TD
    subgraph User Interface
        NextcloudAssistant[Nextcloud Assistant] -->|MCP API| EverLightMCP(EverLight MCP Server)
        CLI[CLI Tool] -->|Direct Access| EverLightCLI(EverLight CLI)
    end

    subgraph Docker Network (everlight_network)
        Nextcloud(Nextcloud Instance) <--> EverLightMCP
        EverLightMCP <--> Ollama(Ollama Model Server)
        EverLightCLI <--> Ollama
        EverLightMCP <--> NextcloudAPI(Nextcloud API Client)
        EverLightCLI <--> NextcloudAPI
    end

    subgraph EverLight Aetherius Archive
        EverLightMCP --> DocumentProcessor[Document Processor]
        EverLightCLI --> DocumentProcessor
        DocumentProcessor --> OllamaClient[Ollama Client]
        DocumentProcessor --> EmbeddingModel[Embedding Model]
        OllamaClient --> Ollama
        EmbeddingModel --> Ollama
        DocumentProcessor --> DocumentStore[Document Store (SQLite)]
        EverLightMCP --> DocumentStore
        EverLightCLI --> DocumentStore
        NextcloudAPI --> Nextcloud
    end

    style Nextcloud fill:#f9f,stroke:#333,stroke-width:2px
    style Ollama fill:#bbf,stroke:#333,stroke-width:2px
    style EverLightMCP fill:#ccf,stroke:#333,stroke-width:2px
    style EverLightCLI fill:#ccf,stroke:#333,stroke-width:2px
    style DocumentProcessor fill:#afa,stroke:#333,stroke-width:2px
    style OllamaClient fill:#afa,stroke:#333,stroke-width:2px
    style EmbeddingModel fill:#afa,stroke:#333,stroke-width:2px
    style DocumentStore fill:#afa,stroke:#333,stroke-width:2px
    style NextcloudAPI fill:#afa,stroke:#333,stroke-width:2px
```

## Project Structure

```
everlight-aetherius-archive/
├── Dockerfile
├── docker-compose.yml          # Defines the Docker stack (Nextcloud, Ollama, EverLight)
├── requirements.txt            # Python dependencies
├── README.md                   # This file
├── config.yaml                 # Main configuration file
├── mcp_server.py               # MCP server entry point
├── cli.py                      # CLI entry point
├── everlight_context/
│   ├── __init__.py
│   ├── config.py               # Configuration management (loads config.yaml, env vars)
│   ├── models/
│   │   ├── __init__.py
│   │   ├── base_model.py       # Abstract base class for LLM models
│   │   ├── ollama_client.py    # Client for local Ollama API
│   │   ├── embedding_model.py  # Embeddings via Ollama and similarity search
│   │   └── document_processor.py # Document processing using Ollama for summarization/analysis
│   ├── mcp/
│   │   ├── __init__.py
│   │   └── server.py           # MCP server implementation (FastAPI)
│   ├── api/
│   │   ├── __init__.py
│   │   ├── nextcloud_client.py # Nextcloud API client (files, assistant)
│   │   └── api_config.py       # API configuration for Nextcloud
│   ├── cli/
│   │   └── __init__.py         # CLI command implementations are in cli.py for simplicity
│   ├── storage/
│   │   ├── __init__.py
│   │   └── document_store.py   # Local document storage and indexing (SQLite)
│   └── logs/                   # Log directory (mounted as volume)
└── data/                       # Document storage directory (mounted as volume)
```

## Setup Instructions (Docker Deployment)

1.  **Prerequisites**:
    *   Docker and Docker Compose installed on your system.
    *   A Cloudflare account and `cloudflared` installed if you plan to use the Cloudflare Tunnel.

2.  **Clone the Repository**:
    ```bash
    git clone <repository_url>
    cd everlight-aetherius-archive
    ```

3.  **Configure `config.yaml`**:
    Review and adjust the `config.yaml` file in the root directory. Key parameters include:
    *   `ollama.url`: Default is `http://ollama:11434` (service name within Docker network).
    *   `ollama.model`: The 3B parameter model you intend to use (e.g., `llama2`).
    *   `nextcloud.url`: Default is `http://nextcloud` (service name within Docker network).
    *   `nextcloud.username`: Your Nextcloud username.
    *   `nextcloud.app_password`: An app-specific password generated in Nextcloud (highly recommended over your main password).
    *   `mcp_server.host` and `mcp_server.port`: For the EverLight MCP server.
    *   `storage.database_path` and `storage.document_path`: Paths within the Docker container, mapped to host volumes.

    **Note**: Sensitive credentials like `nextcloud.username` and `nextcloud.app_password` can be provided via environment variables in `docker-compose.yml` to override values in `config.yaml` (e.g., `NEXTCLOUD_USERNAME`, `NEXTCLOUD_APP_PASSWORD`).

4.  **Prepare Ollama Model**:
    The `docker-compose.yml` will start the Ollama container. You need to pull the desired model (e.g., `llama2`) once it's running. You can do this by executing a command inside the Ollama container:
    ```bash
    docker compose up -d ollama
    docker exec -it ollama ollama pull llama2
    # Replace 'llama2' with your desired 3B parameter model if different
    ```

5.  **Build and Run the Docker Stack**:
    ```bash
    docker compose up --build -d
    ```
    This command will:
    *   Build the `everlight` Docker image.
    *   Start Nextcloud, MariaDB, Ollama, and EverLight containers.
    *   Create `everlight_network` for inter-service communication.
    *   Mount volumes for data persistence (`nextcloud_data`, `db_data`, `ollama_data`, `everlight_data`).

6.  **Cloudflare Tunnel (Optional)**:
    If you wish to expose your Nextcloud and EverLight services securely via Cloudflare Tunnel, uncomment and configure the `cloudflare_tunnel` service in `docker-compose.yml`. You will need to replace `<YOUR_CLOUDFLARE_TUNNEL_TOKEN>` and set up your `TUNNEL_DNS_NAME` and ingress rules accordingly.

## CLI Usage Guide

To interact with the EverLight Aetherius Archive via the CLI, you can execute commands directly within the `everlight` Docker container:

```bash
# Access the EverLight container's shell
docker exec -it everlight_aetherius_archive bash

# Once inside the container, you can run the CLI commands:
python cli.py --help
```

**Available Commands**:

*   `python cli.py process <file_path>`:
    Processes a document (e.g., `/app/data/my_document.txt`), generating a summary, analysis, and embeddings, then stores it in the archive.
    Example: `python cli.py process /app/data/sample.txt`

*   `python cli.py search <query> [--top-k <number>]`:
    Performs a semantic search across archived documents based on the query.
    Example: `python cli.py search 
'AI ethics' --top-k 3`

*   `python cli.py list`:
    Lists all documents currently stored in the archive.

*   `python cli.py summarize <document_id>`:
    Generates and displays a summary for a specific document by its ID.
    Example: `python cli.py summarize doc_id_123`

*   `python cli.py analyze <document_id>`:
    Performs and displays a detailed analysis for a specific document by its ID.
    Example: `python cli.py analyze doc_id_123`

*   `python cli.py status`:
    Checks the connection status to the Ollama service and reports the number of documents in the archive.

*   `python cli.py ingest <directory>`:
    Bulk ingests all readable documents from a specified directory into the archive.
    Example: `python cli.py ingest /app/data/new_documents`

## MCP Server API Documentation

The EverLight Aetherius Archive MCP server exposes the following endpoints for integration with Nextcloud Assistant:

*   **GET `/health`**:
    Checks the health status of the server and its dependencies (e.g., Ollama connection).
    Returns `{"status": "ok", "ollama": "connected"}` on success, or an error if Ollama is unavailable.

*   **GET `/mcp/v1/tools`**:
    Returns a JSON array of available tools that Nextcloud Assistant can invoke. Each tool includes its `name`, `description`, `input_schema`, and `output_schema`.

*   **POST `/mcp/v1/tools/{tool_name}/invoke`**:
    Invokes a specific tool by its `tool_name` with a JSON `payload` as input. The response varies based on the invoked tool.
    *   **`list_documents`**: Returns `{"documents": [...]}`.
    *   **`get_document`**: Requires `{"document_id": "string"}`. Returns `{"document": {...}}`.
    *   **`search_documents`**: Requires `{"query": "string", "top_k": "integer"}`. Returns `{"results": [...]}`.
    *   **`summarize_document`**: Requires `{"document_id": "string"}`. Returns `{"summary": "string"}`.
    *   **`analyze_document`**: Requires `{"document_id": "string"}`. Returns `{"analysis": "string"}`.

*   **GET `/mcp/v1/resources`**:
    Returns a JSON array of available resources that Nextcloud Assistant can access. Each resource includes its `uri`, `description`, and `content_type`.

*   **GET `/mcp/v1/resources/{resource_uri:path}`**:
    Retrieves the content of a specific resource. The `resource_uri` can be:
    *   `archive://index`: Returns a JSON array of document IDs, filenames, and summaries.
    *   `archive://documents/{document_id}`: Returns the plain text content of the specified document.

## Configuration Reference

The `config.yaml` file defines the core configuration for the EverLight Aetherius Archive. Here's a breakdown of its sections:

| Section       | Key              | Description                                                                 | Default Value                  | Environment Variable Override        |
| :------------ | :--------------- | :-------------------------------------------------------------------------- | :----------------------------- | :----------------------------------- |
| `ollama`      | `url`            | URL of the Ollama API server.                                               | `http://ollama:11434`          | `OLLAMA_URL`                         |
|               | `model`          | Name of the 3B parameter LLM model to use for processing.                   | `llama2`                       | `OLLAMA_MODEL`                       |
| `nextcloud`   | `url`            | URL of the Nextcloud instance.                                              | `http://nextcloud`             | `NEXTCLOUD_URL`                      |
|               | `username`       | Nextcloud username for API access.                                          | `${NEXTCLOUD_USERNAME}`        | `NEXTCLOUD_USERNAME`                 |
|               | `app_password`   | Nextcloud app password for API access.                                      | `${NEXTCLOUD_APP_PASSWORD}`    | `NEXTCLOUD_APP_PASSWORD`             |
| `mcp_server`  | `host`           | Host address for the MCP server to bind to.                                 | `0.0.0.0`                      | `MCP_SERVER_HOST`                    |
|               | `port`           | Port for the MCP server to listen on.                                       | `8000`                         | `MCP_SERVER_PORT`                    |
| `storage`     | `database_path`  | Path to the SQLite database file within the container.                      | `/app/data/everlight.db`       | `STORAGE_DATABASE_PATH`              |
|               | `document_path`  | Base path for storing raw document files within the container.              | `/app/data/documents`          | `STORAGE_DOCUMENT_PATH`              |
| `logging`     | `level`          | Logging level (e.g., `INFO`, `DEBUG`, `WARNING`, `ERROR`).                | `INFO`                         | `LOGGING_LEVEL`                      |
|               | `file`           | Path to the log file within the container.                                  | `/app/logs/everlight.log`      | `LOGGING_FILE`                       |

## Development Notes

*   **Type Hinting**: The codebase extensively uses type hints for improved readability and maintainability.
*   **Docstrings**: Comprehensive docstrings are provided for all classes and methods.
*   **Error Handling**: Robust error handling is implemented with meaningful messages and logging.
*   **Asynchronous Operations**: Asynchronous programming (`asyncio`, `httpx.AsyncClient`) is used where appropriate, especially for I/O-bound operations like API calls.
*   **Logging**: The Python `logging` module is used for structured and configurable logging.

---

**Author**: Manus AI
**Version**: 0.1.0
