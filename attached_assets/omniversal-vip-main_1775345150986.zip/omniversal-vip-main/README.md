
# omniversal.vip

Founders console + starter repo for the `omniversal.vip` domain.

This bundle is designed to be:

- **Immediately deployable** as a static site (see `site/`)
- **Ready for GitHub** (init a repo in this directory and push)
- **Jupyter-friendly**, with notebooks under `notebooks/`
- **Script-ready**, with basic helpers in `scripts/`

## Structure

- `site/` — static landing console for omniversal.vip
- `notebooks/` — Jupyter notebooks for domains, agents, and deploy helpers
- `scripts/` — Python helpers for omni-env sync + domain map export

## Quick start

```bash
unzip omniversal_vip_bundle.zip
cd omniversal_vip

# Initialize git (if this is a fresh repo)
git init
git add .
git commit -m "Init omniversal.vip console"

# Push to your remote
git remote add origin <your-github-remote-url>
git push -u origin main

# Deploy to your static host (e.g. Cloudflare Pages, Netlify, S3+CF)
# Use the `site/` directory as the published output.
```

## Notebooks

Open the `notebooks/` directory in JupyterLab or VS Code:

- `00_overview_omniversal_vip.ipynb` — design + intent log
- `01_domain_map_builder.ipynb` — domain lattice builder
- `02_agents_registry.ipynb` — EverLightOS agent registry
- `03_deploy_helpers.ipynb` — deployment notes + snippets

## Scripts

- `scripts/sync_omni_env.py` — merge local `.env` into a shared `omni-env.sh`
- `scripts/generate_domain_map.py` — export the Omniversal domain map as Markdown/JSON

Extend, fork, or gut this as needed — it's meant to be a living console, not a cage.
