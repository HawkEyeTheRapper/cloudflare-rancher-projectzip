
#!/usr/bin/env python3
"""
generate_domain_map.py

Define your Omniversal domain lattice here and export as a simple JSON or Markdown
map that other tools (or agents) can consume.

Run from repo root:

    python3 scripts/generate_domain_map.py --format markdown

"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List


@dataclass
class DomainNode:
    fqdn: str
    role: str
    notes: str = ""


def get_default_domains() -> List[DomainNode]:
    return [
        DomainNode("omniversal.vip", "founders_console", "VIP node · this repo"),
        DomainNode("omniversal.media", "public_brand", "Omniversal Media primary site"),
        DomainNode("everlightos.com", "os_hub", "EverLight OS public docs / hub"),
        DomainNode("everlight-ai.pages.dev", "ai_context", "Context & logs for AI agents"),
        DomainNode("thesentinelframework.com", "evidence_lattice", "Sentinel legal/evidence site"),
        DomainNode("omniversal-aether.online", "aether_stack", "Aether / infra experiments"),
    ]


def export_markdown(domains: List[DomainNode]) -> str:
    lines = ["# Omniversal Domain Map", ""]
    for node in domains:
        lines.append(f"- **{node.fqdn}** — `{node.role}`  ")
        if node.notes:
            lines.append(f"  - {node.notes}")
    lines.append("")
    return "\n".join(lines)


def export_json(domains: List[DomainNode]) -> str:
    return json.dumps([asdict(d) for d in domains], indent=2)


def main() -> None:
    parser = argparse.ArgumentParser(description="Export Omniversal domain map")
    parser.add_argument("--format", choices=["markdown", "json"], default="markdown")
    parser.add_argument("--output", default="domain_map.md")
    args = parser.parse_args()

    domains = get_default_domains()

    if args.format == "markdown":
        content = export_markdown(domains)
    else:
        content = export_json(domains)

    out_path = Path(args.output).resolve()
    out_path.write_text(content)
    print(f"[ok] wrote domain map to {out_path}")


if __name__ == "__main__":
    main()
