
#!/usr/bin/env python3
"""
sync_omni_env.py

Sync project-specific environment variables into a shared omni-env.sh file.

Usage (from repo root):

    python3 scripts/sync_omni_env.py --env .env --omni ../omni-env.sh

This is intentionally conservative: it will only add or update lines that
look like KEY=VALUE pairs and will preserve comments / non-export lines
it doesn't recognize.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict


def parse_env_file(path: Path) -> Dict[str, str]:
    data: Dict[str, str] = {}
    if not path.exists():
        return data
    for line in path.read_text().splitlines():
        raw = line.strip()
        if not raw or raw.startswith("#"):
            continue
        if "=" not in raw:
            continue
        key, value = raw.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            continue
        data[key] = value
    return data


def read_omni_env(path: Path) -> Dict[str, str]:
    data: Dict[str, str] = {}
    if not path.exists():
        return data
    for line in path.read_text().splitlines():
        raw = line.strip()
        if not raw or raw.startswith("#"):
            continue
        if raw.startswith("export "):
            raw = raw[len("export "):]
        if "=" not in raw:
            continue
        key, value = raw.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            continue
        data[key] = value
    return data


def merge_env(existing: Dict[str, str], new: Dict[str, str]) -> Dict[str, str]:
    merged = dict(existing)
    merged.update(new)
    return merged


def write_omni_env(path: Path, data: Dict[str, str]) -> None:
    lines = [
        "# omni-env.sh",
        "# Centralized environment exports for EverLight / Omniversal projects.",
        "# This file can be sourced from per-project shells.",
        "",
    ]
    for key in sorted(data.keys()):
        value = data[key]
        lines.append(f"export {key}={value}")
    lines.append("")
    path.write_text("\n".join(lines))


def main() -> None:
    parser = argparse.ArgumentParser(description="Sync vars into omni-env.sh")
    parser.add_argument("--env", default=".env", help="Path to per-project .env file")
    parser.add_argument(
        "--omni",
        default="../omni-env.sh",
        help="Path to shared omni-env.sh (created if missing)",
    )
    args = parser.parse_args()

    env_path = Path(args.env).expanduser().resolve()
    omni_path = Path(args.omni).expanduser().resolve()

    project_vars = parse_env_file(env_path)
    existing = read_omni_env(omni_path)
    merged = merge_env(existing, project_vars)
    omni_path.parent.mkdir(parents=True, exist_ok=True)
    write_omni_env(omni_path, merged)

    print(f"[ok] merged {len(project_vars)} vars into {omni_path}")


if __name__ == "__main__":
    main()
